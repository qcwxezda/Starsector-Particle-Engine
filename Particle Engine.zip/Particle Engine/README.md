# Starsector-Particle-Engine
Library used for generation of stateless, instanced particles in the game Starsector.
